import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

public class Dao 
{
	//connection
		public static Connection getconnect()
		{
			Connection con = null;
			
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/servletcrud","root","");
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
		}
		
		//insert
		
		public static int insertdata(Model m)
		{
			int status = 0;
			Connection con = Dao.getconnect();
			try 
			{
				PreparedStatement ps = (PreparedStatement) con.prepareStatement("insert into productreg(pname,pbrand,pid,pdate,ppprice,psprice) value(?,?,?,?,?,?)");
				ps.setString(1, m.getPname());
				ps.setString(2, m.getPbrand());
				ps.setString(3, m.getPid());
				ps.setString(4, m.getPdate());
				ps.setString(5, m.getPpprice());
				ps.setString(6, m.getPsprice());
				
				status = ps.executeUpdate();
				
			
			}
			catch (Exception e) 
			{ 
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return status;
		}
		
		//view
		
				public static List<Model> viewdata()
				{
					Connection con = Dao.getconnect();
					ArrayList<Model> list = new ArrayList();
					try 
					{
						PreparedStatement	ps = (PreparedStatement) con.prepareStatement("select * from productreg");
						
						ResultSet set =ps.executeQuery();
						
						while(set.next())
						{
							int id = set.getInt(1);
							String pname = set.getString(2);
							String pbrand = set.getString(3);
							String pid = set.getString(4);
							String pdate = set.getString(5);
							String ppprice = set.getString(6);
							String psprice = set.getString(7);
							
							Model m = new Model();
							m.setId(id);
							m.setPname(pname);
							m.setPbrand(pbrand);
							m.setPid(pid);
							m.setPdate(pdate);
							m.setPdate(ppprice);
							m.setPdate(psprice);
							
							list.add(m);
						}
					
					
					}
					catch (Exception e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				
					return list;
				
			}
				
				
				
		//-----------------------------------------------------------------------------------------------------------------
				
				//insert
				
				public static int insertuserdata(Model2 m2)
				{
					int status = 0;
					Connection con = Dao.getconnect();
					try 
					{
						PreparedStatement ps2 = (PreparedStatement) con.prepareStatement("insert into registrationform(fname,lname,uname,bdate,password,cpassword,email,mno) value(?,?,?,?,?,?,?,?)");
						ps2.setString(1, m2.getFname());
						ps2.setString(2, m2.getLname());
						ps2.setString(3, m2.getUname());
						ps2.setString(4, m2.getBdate());
						ps2.setString(5, m2.getPassword());
						ps2.setString(6, m2.getCpassword());
						ps2.setString(7, m2.getEmail());
						ps2.setString(8, m2.getMno());
						
						status = ps2.executeUpdate();
						
					
					}
					catch (Exception e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return status;
				}
				
				//view
				
				public static List<Model2> viewdata2()
				{
					Connection con = Dao.getconnect();
					ArrayList<Model2> list = new ArrayList();
					try 
					{
						PreparedStatement	ps2 = (PreparedStatement) con.prepareStatement("select * from registrationform");
						
						ResultSet set =ps2.executeQuery();
						
						while(set.next())
						{
							int id = set.getInt(1);
							String fname = set.getString(2);
							String lname = set.getString(3);
							String uname = set.getString(4);
							String bdate = set.getString(5);
							String password = set.getString(6);
							String cpassword = set.getString(7);
							String email = set.getString(8);
							String mno = set.getString(9);
							
							Model2 m2 = new Model2();
							m2.setId(id);
							m2.setFname(fname);
							m2.setLname(lname);
							m2.setUname(uname);
							m2.setBdate(bdate);
							m2.setPassword(password);
							m2.setCpassword(cpassword);
							
							list.add(m2);
						}
					
					
					}
					catch (Exception e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				
					return list;
				
			}
				
}



