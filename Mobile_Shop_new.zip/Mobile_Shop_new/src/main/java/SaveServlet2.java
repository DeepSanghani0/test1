import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaveServlet2 extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
	
				resp.setContentType("text/html");
				PrintWriter out = resp.getWriter();
		
		
				String fname = req.getParameter("fname");
				String lname = req.getParameter("lname");
				String uname = req.getParameter("uname");
				String bdate = req.getParameter("bdate");
				String password = req.getParameter("password");
				String cpassword = req.getParameter("cpassword");
				String email = req.getParameter("email");
				String mno = req.getParameter("mno");
				
				
				Model2 m2 = new Model2();
				m2.setFname(fname);
				m2.setLname(lname);
				m2.setUname(uname);
				m2.setBdate(bdate);
				m2.setPassword(password);
				m2.setCpassword(cpassword);
				m2.setEmail(email);
				m2.setMno(mno);

				
				
				int data = Dao.insertuserdata(m2);
				
				if(data>0)
				{
//					out.print("success");
					resp.sendRedirect("ViewServlet2");
				}
				
				else
				{
					out.print("fail");
				}
				
				
//				System.out.println(pname+" "+pbrand+" "+pid+" "+pdate+" "+ppprice+" "+psprice+" ");
//				out.print("<br>");
//				out.print("Your Name is : "+pname);
//				out.print("<br>");
//				out.print("Your Surname is : "+pbrand);
//				out.print("<br>");
//				out.print("Your Email is : "+pid);
//				out.print("<br>");
//				out.print("Your Bdate is : "+pdate);
//				out.print("<br>");
//				out.print("Your ppprice is : "+ppprice);
//				out.print("<br>");
//				out.print("Your psprice is : "+psprice);
//				out.print("<br>");
				
	}
	
	
}
