import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaveServlet extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
	
				resp.setContentType("text/html");
				PrintWriter out = resp.getWriter();
		
		
				String pname = req.getParameter("pname");
				String pbrand = req.getParameter("pbrand");
				String pid = req.getParameter("pid");
				String pdate = req.getParameter("pdate");
				String ppprice = req.getParameter("ppprice");
				String psprice = req.getParameter("psprice");
				
				
				Model m = new Model();
				m.setPname(pname);
				m.setPbrand(pbrand);
				m.setPid(pid);
				m.setPdate(pdate);
				m.setPpprice(ppprice);
				m.setPsprice(psprice);

				
				
				int data = Dao.insertdata(m);
				
				if(data>0)
				{
//					out.print("success");
					resp.sendRedirect("ViewServlet");
				}
				
				else
				{
					out.print("fail");
				}
				
				
				System.out.println(pname+" "+pbrand+" "+pid+" "+pdate+" "+ppprice+" "+psprice+" ");
				out.print("<br>");
				out.print("Your Name is : "+pname);
				out.print("<br>");
				out.print("Your Surname is : "+pbrand);
				out.print("<br>");
				out.print("Your Email is : "+pid);
				out.print("<br>");
				out.print("Your Bdate is : "+pdate);
				out.print("<br>");
				out.print("Your ppprice is : "+ppprice);
				out.print("<br>");
				out.print("Your psprice is : "+psprice);
				out.print("<br>");
				
	}
	
	
}
