
public class Model 
{
	int id;
	String pname,pbrand,pid,pdate,ppprice,psprice;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPbrand() {
		return pbrand;
	}
	public void setPbrand(String pbrand) {
		this.pbrand = pbrand;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPpprice() {
		return ppprice;
	}
	public void setPpprice(String ppprice) {
		this.ppprice = ppprice;
	}
	public String getPsprice() {
		return psprice;
	}
	public void setPsprice(String psprice) {
		this.psprice = psprice;
	}
	
	
}
