package Module_1;

/*1. Display This Information using println
	a. Your Name
	b. Your Birth date
	c. Your Age
	d. Your Address
*/
public class display 
{
	
	public static void main(String[] args) 
	{
		System.out.println("My name is Deep Sanghani");
		System.out.println("My Birthdate is 4th april");
		System.out.println("My age is 23");
		System.out.println("Address: nr. hanuman temple theba, jamnagar");
	}

}
