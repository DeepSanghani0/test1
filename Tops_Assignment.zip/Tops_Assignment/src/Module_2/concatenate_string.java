package Module_2;
//• W.A.J.P to concatenate a given string to the end of another string.
public class concatenate_string 
{

	public static void main(String[] args) 
	{
	
		String s1 = "Deep";
		String s2 = s1.concat(" Sanghani");
		
		System.out.println(s2);
		
	}
	
}
