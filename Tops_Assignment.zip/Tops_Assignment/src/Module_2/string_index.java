package Module_2;
//• W.A.J.P to get the character at the given index within the String. Original String = Tops Technologies! The character at position 0 is T, The character at position 10 is o
public class string_index 
{

	public static void main(String[] args) 
	{
		String s1 = "Tops Technologies!";
		
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(10));
	}
	
}
