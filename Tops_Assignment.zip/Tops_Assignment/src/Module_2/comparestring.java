package Module_2;
/*
 * • W.A.J.P to compare a given string to the specified character sequence. Comparing topsint.com and topsint.com: true Comparing Topsint.com and topsint.com: false
 */
public class comparestring 
{
	public static void main(String[] args) 
	{
		String s1 = "topsint.com";
		String s2 = "topsint.com";
		String s3 = "Topsint.com";

		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
	}
	
}
