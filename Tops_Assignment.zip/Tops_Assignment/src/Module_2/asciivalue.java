package Module_2;
//• Write a Java program to print the ASCII value of a given character.
import java.util.Scanner;

public class asciivalue 
{

	public static void main(String[] args) 
	{
	
		char ch = 'b';
		int  no = (int)ch;
		System.out.println(no);
		
	}
	
}
