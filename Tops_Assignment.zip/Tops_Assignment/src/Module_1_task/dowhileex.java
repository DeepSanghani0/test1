//package Module_1_task;
//c. write a program to print the 100 to 81 using do....while loop
public class dowhileex 
{
	public static void main(String[] args) 
	{
		int i = 100;
		do 
		{
			System.out.println(i);
			i--;
		}
		while(i>=81);
	}
}
