package Module_1_task;
//b. Write a Program to print the 51 to 60 using while loop
public class forloopex2 
{
	public static void main(String[] args) 
	{
		for(int i = 51;i<=60;i++)
		{
			System.out.println(i);
		}
	}
}
