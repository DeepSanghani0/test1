package Module_1_task;
//a. Write a program to print the 1 to 10 using For in loop.
public class forloop 
{
	public static void main(String[] args) 
	{
		for(int i = 1;i<=10;i++)
		{
			System.out.println(i);
		}
	}
}
