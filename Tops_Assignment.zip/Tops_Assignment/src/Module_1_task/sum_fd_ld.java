package Module_1_task;

import java.util.Scanner;

//j.Write a program you have to make a summation of first and last Digit.
public class sum_fd_ld 
{
	public static void main(String[] args) 
	{
		int fdig,ld,sum;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter any number: ");
		int no = obj.nextInt();
		
	}
}
