

abstract class A
{
	
	protected void a() {
		
	}
	abstract void b();
	
}

class B extends A
{

	@Override
	void b() 
	{
		// TODO Auto-generated method stub
		
	}
}

class c
{
	private void c()
	{
		
	}
	
}

public class abstractex 
{
	
	static void display()
	{
		B obj = new B();
		obj.a();
		obj.b();
	}
	
	public static void main(String[] args) 
	{
		display();
	}
}
