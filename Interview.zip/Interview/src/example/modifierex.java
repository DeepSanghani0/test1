package example;

import com.a.abstractex;

public class modifierex 
{
	public static void main(String[] args) 
	{
		abstractex a1 = new abstractex();
		
		abstractex.E();
		//B b = new B();
	}
}
