

public class DoWhileLoop {
	public static void main(String[] args) {
		int a=1;
		do {
			System.out.println("TOPS  - "+a);
			a++;
		}while(a<=10);
	}
}