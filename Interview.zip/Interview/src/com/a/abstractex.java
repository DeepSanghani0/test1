package com.a;


abstract class A
{
	
	protected void a() {
		
	}
	abstract void b();
	
	 void c() {
		
	}
	
}

 class B extends A  
{

	@Override
	void b() 
	{
		// TODO Auto-generated method stub
		
	}
}

class c 
{
	private void c()
	{
		
	}
	
}

public class abstractex 
{
	static void D()
	{
		B obj = new B();
		obj.a();
		obj.b();
		obj.c();
	}
	
	public static void E()
	{
		System.out.println("E method");
	}
	
	public static void main(String[] args) 
	{
		D();
	}
}
