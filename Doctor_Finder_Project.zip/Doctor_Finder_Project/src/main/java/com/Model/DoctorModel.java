package com.Model;

public class DoctorModel 
{
	int id;
	String name,img,speciality,experience,edu_bkg;
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getEdu_bkg() {
		return edu_bkg;
	}
	public void setEdu_bkg(String edu_bkg) {
		this.edu_bkg = edu_bkg;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	
	
}
