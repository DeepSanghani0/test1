package com.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Model.DoctorModel;
import com.Model.model;





//Connection
public class dao 
{
	public static Connection getconnect()
	{
		Connection con = null;
		
		try 
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager .getConnection("jdbc:mysql://localhost:3306/doctor_finder","root","");;
			
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
	
	//Signup
	public static int savedata(model m)
	{
		int status = 0;
			
		Connection con = dao.getconnect();
		
		try 
			{
				PreparedStatement ps = con.prepareStatement("insert into signup (name,surname,phone,email,gender,password,cpassword) values(?,?,?,?,?,?,?)");
				ps.setString(1, m.getName());
				ps.setString(2, m.getSurname());
				ps.setString(3, m.getPhone());
				ps.setString(4, m.getEmail());
				ps.setString(5, m.getGender());
				ps.setString(6, m.getPassword());
				ps.setString(7, m.getCpassword());
				
				status = ps.executeUpdate();
			} 
		catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return status;
	}
	
	//Login
	
	public static model login(model m1)
	{
		
	

		model obj = null;

		try {
			Connection con = dao.getconnect();
			PreparedStatement ps = con.prepareStatement("select * from signup where email=? and password=?");
			ps.setString(1, m1.getEmail());
			ps.setString(2, m1.getPassword());

			ResultSet rs = ps.executeQuery();

			if (rs.next()) 
			{
				obj = new model();
				obj.setId(rs.getInt("id"));
				obj.setName(rs.getString("name"));
				obj.setSurname(rs.getString("surname"));
				obj.setPhone(rs.getString("phone"));
				obj.setEmail(rs.getString("email"));
				obj.setGender(rs.getString("gender"));
				obj.setPassword(rs.getString("password"));
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return obj;

	}
	
	
	//edit
	
		public static model getdetailbyemail(String email)
		{
			model m = new model();
			
			Connection con = dao.getconnect();
			try 
			{
				PreparedStatement ps = con.prepareStatement("Select * from signup where email=?");
				ps.setString(1,email);
				ResultSet set = ps.executeQuery();
				
				if(set.next())
				{
					int id = set.getInt(1);
					String name = set.getString(2);
					String surname = set.getString(3);
					String phone = set.getString(4);
					String email1 = set.getString(5);
					String gender = set.getString(6);
					String password = set.getString(7);
					
					m.setId(id);
					m.setName(name);
					m.setSurname(surname);
					m.setPhone(phone);
					m.setEmail(email1);
					m.setGender(gender);
					m.setPassword(password);
				}
			} 
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return m;
		}
	
		//Update
		public static int updatedata(model m)
		{
			int status = 0;
			Connection con = dao.getconnect();
			try 
			{
				PreparedStatement ps = con.prepareStatement("update signup set name=?,surname=?,phone=?,email=?,gender=? where id=?");
				
				ps.setString(1,m.getName());
				ps.setString(2,m.getSurname());
				ps.setString(3,m.getPhone());
				ps.setString(4,m.getEmail());
				ps.setString(5,m.getGender());
				ps.setInt(6,m.getId());
				
				status = ps.executeUpdate();
			
			}
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return status;
		}
		
		
		//view Doctor
	
		public static List<DoctorModel> doctorviewdata()
		{
			Connection con = dao.getconnect();
			ArrayList<DoctorModel> list = new ArrayList();
			try 
			{
				PreparedStatement	ps = con.prepareStatement("select * from doctors");
				
				ResultSet set =ps.executeQuery();
				
				while(set.next())
				{
					int id = set.getInt(1);
					String name = set.getString(2);
					String img = set.getString(3);
					String speciality = set.getString(4);
					String experience = set.getString(5);
					String edu_bkg = set.getString(6);
					
					DoctorModel m = new DoctorModel();
					m.setId(id);
					m.setName(name);
					m.setImg(img);
					m.setSpeciality(speciality);
					m.setExperience(experience);
					m.setEdu_bkg(edu_bkg);
				
					list.add(m);
				}
			
			
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
			return list;
		
		}
		
}



